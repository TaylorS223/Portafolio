# Trabajo en clase utilizando React, UseEffect y UseState

Integrantes:
Taylor Steven Alava Gresely
David Alejandro Vilañez Palma
Jordan Josue Lema Ayala